from distutils.core import setup

setup(name='PythonTerm',
      version='1.0',
      py_modules=['GUITk', 'internetMovie']
      )